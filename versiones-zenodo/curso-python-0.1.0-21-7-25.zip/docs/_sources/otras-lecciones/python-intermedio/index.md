---
parent: "Otras lecciones"
has_children: true
---

# Python Intermedio

Esta carpeta contiene algunos conceptos necesario para el dominio intermedio de python.
