---
parent: "Unidad 1: Aspectos Básicos"
nav_order: 2
has_children: true
---

# Tema 2: Generalidades

## Objetivo de aprendizaje

El alumno conocerá qué es la programación, cómo fragmentar problemas en unidades esenciales, y cómo python ayuda a resolver estos problemas.

:::{tip}
La parte 3 de este trata sobre muchos aspectos de python, pero debe servir más como referencia que como algo a entender o dominar en este momento.
:::