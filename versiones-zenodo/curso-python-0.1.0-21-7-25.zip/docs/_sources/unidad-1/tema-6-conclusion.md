---
parent: "Unidad 1: Aspectos Básicos"
nav_order: 6
---

# Tema 6: Conclusiones 

En esta unidad hemos visto generalidades muy consisas de todo lo que veremos en el resto del curso.

Hasta este momento tu conocimiento debe ser cómo crear un entorno local de trabajo, al usar `uv` y `jupyter lab`, y cómo analizar un problema para separarlo en pasos esenciales y de ahí planear un programa. 

En la siguiente unidad aprenderás a escribir código simple, la finalidad es clara **Utilizar python como calculadora**. Aprenderás el verdadero poder de la programación y te prepararás para taclear problemas más complejos.
