# Unidad 1: Aspectos Básicos

Al finalizar esta unidad, comprenderás los fundamentos generales de la programación, el lenguaje Python y su utilidad, conocerás cómo preparar tu entorno de trabajo y podrás ejecutar código en diferentes plataformas.
