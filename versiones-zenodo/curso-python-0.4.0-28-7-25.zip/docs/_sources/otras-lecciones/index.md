---
has_children: true
---

# Otras lecciones

Esta carpeta contiene conocimiento que no es necesario para completar el curso, es un complemento de los demás temas.
