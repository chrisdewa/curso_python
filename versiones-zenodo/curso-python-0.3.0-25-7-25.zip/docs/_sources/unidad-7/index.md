# Unidad 7: Libretas reutilizables

En esta unidad encontrarás libretas que pueden ser utilizadas de forma inmediata en google colab o en forma local, cada una ayuda en algunos análisis sencillos y frecuentes; dicho de otra forma, son calculadoras.

Su objetivo es doble, en primer lugar, buscan ser útiles para tí, para que puedas realizar análisis frecuentes de forma sencilla y transparente. En segundo lugar, te ofrecen una experiencia diferente de aprendizaje fundamentada en el código reutilizable.

:::{warning}
Sección en construcción. El código puede no estar disponible o ser inestable.
:::