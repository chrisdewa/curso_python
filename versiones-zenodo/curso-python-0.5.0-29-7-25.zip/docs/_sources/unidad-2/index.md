
# Unidad 2: Python como calculadora

En esta unidad comenzaremos a programar formalmente, te darás una idea del tipo de problemas que python puede ayudar a resolver. Asignaremos variables, resolveremos problemas específicos de creciente complejidad. 


:::{tip}
A partir de aquí, prácticamente todos los temas se abordarán en libretas jupyter. Recuerda descargarlas con <i class="fas fa-download"></i> y agregarlas a tu entorno de trabajo, es decir, copiarlas a la carpeta del curso.

Solo en caso de que te sea imposible trabajar en forma local, puedes utilizar el botón <i class="fas fa-rocket"></i> para abrir la libreta en google colab.
:::
