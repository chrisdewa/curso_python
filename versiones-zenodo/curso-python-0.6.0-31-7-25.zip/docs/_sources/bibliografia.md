

# Bibliografía

## Librerías

- **ArviZ** {cite}`Kumar2019`  
- **Bambi** {cite}`Capretto2022`  
- **Lifelines**  {cite}`Davidson-Pilon2019`  
- **Matplotlib**  {cite}`Hunter2007matplotlib`  
- **NumPy** {cite}`Harris2020numpy`
- **Pandas** {cite}`pandas2025`
- **Pingouin**  {cite}`Vallat2018`  
- **SciPy** {cite}`Virtanen2020scipy`  
- **scikit‑learn**  {cite}`Pedregosa2011sklearn`  
- **seaborn** {cite}`Waskom2021seaborn`  
- **statsmodels** {cite}`seabold2010statsmodels`



## Referencias Bibliográficas

Aquí se enlistan todas las referencias del libro.

```{bibliography}
:style: unsrt
```