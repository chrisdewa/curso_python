# Ejercicios lógicos

En esta sección encontrarás ejercicios lógicos para ejercitar el pensamiento programático y tus habilidades en python.

Cada libreta es un ejercicio, la mayoría de ellos son muy sencillos. 

Se sugiere trabajar directamente en Colab <i class="fas fa-rocket"></i>, no es necesario descargar las libretas.

:::{important}
Todas estos ejercicios deben realizarse sin utilizar librerías externas (como `pandas` o `numpy`), solo utiliza librerías internas de python.
:::